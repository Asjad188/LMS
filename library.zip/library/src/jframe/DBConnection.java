package jframe;
import java.sql.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;

public class DBConnection {
    static Connection con=null;
    
    public static Connection getConnection(){
    try {
     Class.forName("com.mysql.jdbc.Driver");
    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms","root","");
          PreparedStatement pst=con.prepareStatement("select * from users" );
        String sql = null;

    ResultSet rs=pst.executeQuery(sql);
       
 }catch (Exception e){
     e.printStackTrace();
    }
    return con;

    
}

}
